﻿using ECommerce_App.IECommerce;
using System;

namespace ECommerce_App
{
    class Program
    {
        
        static void Main(string[] args)
        {
            IECommerceService eCommerce = new ECommerceFactory();
            try
            {
                eCommerce.DisplayItems();

                Console.WriteLine();
                Console.WriteLine();

                //add user items in collection class
                eCommerce.AddUserItem();
                //display user item list from User Item collection list
                eCommerce.DisplayUserItems();

            }
            catch (Exception ex)
            {
                Console.WriteLine("User Exception Occures or user input wrong, Please Restart the Application");
            }

            finally {
                Console.ReadLine();
            }
            //display items list
            
        }        
        
    }
}
