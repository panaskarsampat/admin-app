﻿using ECommerce.BusinessLayer;
using ECommerce.BusinessLayer.IService;
using ECommerce.Entities;
using ECommerce_App.IECommerce;
using System;
using System.Collections.Generic;

namespace ECommerce_App
{
    public class ECommerceFactory : IECommerceService
    {
        private static List<UserItemModel> userItemList = new List<UserItemModel>();
        private static IUserItemService userItemService = new UserItemService();
        private static double grandTotal;
        public IList<UserItemModel> AddUserItem()
        {           
            Console.Write("Enter Item Code: ");
            string _code = Console.ReadLine();

            Console.WriteLine();
            Console.Write("Enter Item Quantity: ");
            string _qty = Console.ReadLine();

            return userItemService.AddUserItem(Convert.ToInt32(_code), Convert.ToInt32(_qty), userItemList);
        }

        public void CalCulateDiscount()
        {
            Console.WriteLine();
            Console.Write("1. Discount for all  2. Discount on Item, Your Choice: ");
            string discType = Console.ReadLine();
            Console.WriteLine();
            if (discType == "1") {
                grandTotal = userItemService.DiscountType(discType, grandTotal, userItemList, 0);
            }
            else {
                Console.WriteLine();
                Console.Write("Enter Item Code: ");
                string _code = Console.ReadLine();
                Console.WriteLine();
                grandTotal = userItemService.DiscountType(discType, grandTotal, userItemList, Convert.ToInt32(_code));
            }
            CalculateSubTotal();
        }

        public void CalculateSubTotal()
        {
            Console.Write("--------------------------------");
            Console.WriteLine("Grand Total: {0}", grandTotal);
        }

        public void DisplayItems()
        {            
            foreach (ItemModel i in LoadItems())
            {
                Console.Write("{0}.{1} ", i.ItemCode, i.ItemName);
            }
        }

        public void DisplayUserItems()
        {
            Console.WriteLine();
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine("Code   Item          Price   Qty     Total");
            Console.WriteLine("----------------------------------------------");
            grandTotal = 0;
            foreach (UserItemModel i in userItemList)
            {
                Console.WriteLine("{0}      {1}         {2}    {3}      {4}", i._UserItem.ItemCode, i._UserItem.ItemName, i._UserItem.ItemPrice, i.Quantity, i.ItemTotal);
                grandTotal = grandTotal + i.ItemTotal;
            }

            Console.WriteLine();            
            CalculateSubTotal();

            //repeat add user item
            Console.WriteLine();
            UserChoice();
        }

        public IList<ItemModel> LoadItems()
        {
            IItemService itemService = new ItemService();
            IList<ItemModel> items = itemService.GetItems();
            return items;
        }

        public void UserChoice()
        {
            Console.Write("Enter 1 for Add New and other for Discount Calculation: ");            
            int _choice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();

            switch (_choice) {
                case 1:
                    AddUserItem();
                    DisplayUserItems();
                    break;
                default:
                    CalCulateDiscount();
                    break;
            }
        }
    }
}
