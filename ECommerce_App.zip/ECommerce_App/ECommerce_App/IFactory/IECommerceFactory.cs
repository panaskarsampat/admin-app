﻿using ECommerce.Entities;
using System.Collections.Generic;

namespace ECommerce_App.IECommerce
{
    public interface IECommerceService
    {
        IList<ItemModel> LoadItems();
        void DisplayItems();
        IList<UserItemModel> AddUserItem();
        void DisplayUserItems();
        void CalculateSubTotal();
        void UserChoice();
        void CalCulateDiscount();
    }
}
