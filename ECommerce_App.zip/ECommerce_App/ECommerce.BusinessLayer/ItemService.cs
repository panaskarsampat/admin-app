﻿using ECommerce.BusinessLayer.IService;
using ECommerce.DataLayer;
using ECommerce.DataLayer.IRepository;
using ECommerce.Entities;
using System.Collections.Generic;
using System.Linq;

namespace ECommerce.BusinessLayer
{
    public class ItemService : IItemService
    {
        private IItemRepository itemRepository;

        public ItemService()
        {
            itemRepository = new ItemRepository();
        }

        public ItemModel GetItemByCode(int _code)
        {
            return itemRepository.GetItems().FirstOrDefault(i => i.ItemCode == _code);
        }

        public List<ItemModel> GetItems()
        {
            return itemRepository.GetItems();
        }

        
    }
}
