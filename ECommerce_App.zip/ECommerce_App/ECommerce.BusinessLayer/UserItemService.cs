﻿using ECommerce.BusinessLayer.IService;
using ECommerce.Entities;
using System;
using System.Collections.Generic;

namespace ECommerce.BusinessLayer
{
    public class UserItemService : IUserItemService
    {
        private IItemService itemService;
        public UserItemService() {
            itemService = new ItemService();
        }
        public List<UserItemModel> AddUserItem(int _code, int _qty, List<UserItemModel> userItems)
        {
            UserItemModel userItem = new UserItemModel();

            userItem._UserItem = itemService.GetItemByCode(_code);

            userItem.Quantity = _qty;
            userItem.ItemTotal = userItem._UserItem.ItemPrice * _qty;

            userItems.Add(userItem);

            return userItems;

        }
        
        public double CalculateDiscount(double subTotal)
        {
            double disc = 0;

            disc = Math.Round(subTotal - subTotal * (Convert.ToDouble(10) / 100));

            return disc;
        }

        public double CalculateItemDiscount(double subTotal, List<UserItemModel> userItems, int _code)
        {
            double disc=0;
            bool isDisc = false;
            foreach(UserItemModel um in userItems)
            {
                if (um._UserItem.ItemCode == _code) {
                    disc = Math.Round(subTotal - (um._UserItem.ItemPrice*um.Quantity) * (Convert.ToDouble(10) / 100));
                    isDisc = true;
                }
            }
            if (isDisc)
            {
                return disc;
            }
            else {
                disc = subTotal;
                return disc;
            }
            
        }

        //public List<UserItemModel> BuyTwoGetOne(List<UserItemModel> userItems, int _code) {
        //    foreach (UserItemModel um in userItems)
        //    {
        //        if (um._UserItem.ItemCode == _code)
        //        {
        //            um.Quantity = um.Quantity + 1;
        //            userItems.Add(um);
        //        }
        //    }
        //    return userItems;
        //}

        public double DiscountType(string _discType, double grdTotal, List<UserItemModel> userItems, int _code)
        {
            double discTotal = 0;
            switch (_discType)
            {
                case "1":
                    discTotal = CalculateDiscount(grdTotal);
                    break;
                case "2":
                    discTotal = CalculateItemDiscount(grdTotal, userItems, _code);
                    break;
                //case "3":
                //    BuyTwoGetOne(userItems, _code);
                //    break;
            }
            return discTotal;
        }
    }
}
