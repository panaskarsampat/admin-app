﻿using ECommerce.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.BusinessLayer.IService
{
    public interface IUserItemService
    {
        List<UserItemModel> AddUserItem(int _code, int _qty, List<UserItemModel> userItems);
        double CalculateItemDiscount(double subTotal, List<UserItemModel> userItems, int _code);
        double CalculateDiscount(double subTotal);
        double DiscountType(string _discType, double subTotal, List<UserItemModel> userItems, int _code);
    }
}
