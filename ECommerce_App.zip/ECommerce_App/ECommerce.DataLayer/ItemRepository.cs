﻿using ECommerce.DataLayer.IRepository;
using ECommerce.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.DataLayer
{
    public class ItemRepository : IItemRepository
    {
        public List<ItemModel> GetItems()
        {
            return new List<ItemModel>() {
                new ItemModel(){ItemCode=1, ItemName="Mouse", ItemPrice=155.55},
                new ItemModel(){ItemCode=2, ItemName="Keyboard", ItemPrice=755},
                new ItemModel(){ItemCode=3, ItemName="Monitor", ItemPrice=5500},
                new ItemModel(){ItemCode=4, ItemName="CPU", ItemPrice=8000},
                new ItemModel(){ItemCode=5, ItemName="Laptop", ItemPrice=55000},
                new ItemModel(){ItemCode=6, ItemName="USB Cable", ItemPrice=55.55}
            };
        }
    }
}
