﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECommerce.Entities;

namespace ECommerce.DataLayer.IRepository
{
    public interface IItemRepository
    {
        List<ItemModel> GetItems();
    }
}
