﻿using DiscountLibrary.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiscountLibrary.Class
{
    public class PriceDiscount_15 : IPriceDiscount
    {
        public double CalculateDiscount(double Amount)
        {
            return 15;
        }
    }
}
