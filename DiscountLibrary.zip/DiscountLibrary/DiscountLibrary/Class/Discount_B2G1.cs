﻿using DiscountLibrary.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiscountLibrary.Class
{
    public class Discount_B2G1 : IQtyDiscount
    {
        public int CalculateDiscount(int Qty)
        {
            return 3;
        }
    }
}
