﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiscountLibrary.Interfaces;

namespace DiscountLibrary.Class
{
    public class ConcreteDiscountFactory : DiscountFactory
    {
        public override IPriceDiscount GetDiscount(int discType)
        {
            switch (discType)
            {
                case 10:
                    return new PriceDiscount_10();
                case 15:
                    return new PriceDiscount_15();
                    case 
                default:
                    throw new ApplicationException(string.Format("Vehicle '{0}' cannot be created", discType));
            }
        }
    }
}
