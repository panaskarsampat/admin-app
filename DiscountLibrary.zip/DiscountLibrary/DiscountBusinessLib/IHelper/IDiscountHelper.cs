﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiscountEntitiesLib;

namespace DiscountBusinessLib.IHelper
{
    public interface IDiscountHelper
    {
        List<Product> GetAllProducts();
        List<UserCart> AddUserProduct(int pId, int pQty);
        void CalculateAllDiscount();
        UserCart CalculateProductDiscount(int pId);
        List<UserCart> CalculateQtyDiscount(int pId);
        double _subTot { get; }
        double _grandTot { get; set; }    
    }
}
