﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AbstractDiscLib;
using DiscountEntitiesLib;
using DiscountBusinessLib.IHelper;
using AbstractDiscLib.Factory.IFactory;
using AbstractDiscLib.Product.IProduct;
using AbstractDiscLib.Product;
using AbstractDiscLib.Factory;

namespace DiscountBusinessLib
{
    public class DiscountHelper : IDiscountHelper
    {
        List<UserCart> UserProducts = new List<UserCart>();
        List<Product> products { get { return ProductLists.GetProducts(); } }

        public double _subTot { get {
                double tot = 0;
                foreach (var itm in UserProducts)
                {
                    tot +=itm._Total;
                }
                return tot;
            }
        }

        public double _grandTot { get; set; }

        public DiscountHelper() {

        }
        public DiscountHelper(List<UserCart> _userCarts) {
            this.UserProducts = _userCarts;
        }
        
        private void CalculateForAll()
        {
            AbstractDiscountFactory _discount = new ConcreateDiscountFactory();
            DiscountClient _discount_client = new DiscountClient(_discount, 10);
            _grandTot = _discount_client.GetPriceDiscount(_subTot);
        }
                
        public void CalculateAllDiscount()
        {
            CalculateForAll();
        }

        public UserCart CalculateProductDiscount(int pId)
        {
            UserCart userCart = new UserCart();
            _grandTot = 0;
            foreach (UserCart uc in UserProducts)
            {
                userCart = uc;
                userCart._DisTotal = uc._Total;
                if (uc._Product.ProductId == pId)
                {                    
                    AbstractDiscountFactory _discount = new ConcreateDiscountFactory();
                    DiscountClient _discount_client = new DiscountClient(_discount, 15);
                   
                    userCart._DisTotal = _discount_client.GetPriceDiscount(CalculateProductQty(uc._Qty, uc._Product.ProductPrice));                  
                }
                _grandTot += userCart._DisTotal;
            }
            return userCart;
        }

        private double CalculateProductQty(int pQty, double pPrice)
        {
            return pPrice * pQty;
        }
        public List<UserCart> AddUserProduct(int pId, int pQty)
        {
            UserCart uc;
            foreach(Product p in products)
            {                
                if (p.ProductId == pId)
                {
                    uc = new UserCart();

                    uc._Product = p;
                    uc._Qty = pQty;
                    uc._Total = CalculateProductQty(pQty, p.ProductPrice);

                    UserProducts.Add(uc);
                }                
            }
            
            return UserProducts;
        }

        public List<Product> GetAllProducts()
        {           
            return products;
        }

        public List<UserCart> CalculateQtyDiscount(int pId) {
            foreach(UserCart uc in UserProducts)
            {
                if (uc._Product.ProductId == pId)
                {
                    AbstractDiscountFactory _discount = new ConcreateDiscountFactory();
                    DiscountClient _discount_client = new DiscountClient(_discount, 15);
                    uc._Qty = _discount_client.GetQtyDiscount(uc._Qty);
                }
            }
            return UserProducts;
        }
    }
}
