﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiscountEntitiesLib;

namespace DiscountBusinessLib
{
    public static class ProductLists
    {
        public static List<Product> GetProducts() {
            return new List<Product>() {
                new Product(){ProductId=1, ProductName="Mouse", ProductPrice=155.55},
                new Product(){ProductId=2, ProductName="Keyboard", ProductPrice=755},
                new Product(){ProductId=3, ProductName="Monitor", ProductPrice=5500},
                new Product(){ProductId=4, ProductName="CPU", ProductPrice=8000},
                new Product(){ProductId=5, ProductName="Laptop", ProductPrice=55000},
                new Product(){ProductId=6, ProductName="USB Cable", ProductPrice=55.55}
            };
        }
    }
}
