﻿using DiscountBusinessLib;
using DiscountBusinessLib.IHelper;
using DiscountEntitiesLib;
using System;
using System.Collections.Generic;

namespace DiscountPricing
{
    class Program
    {
        private static List<UserCart> _userCarts = new List<UserCart>();
        private static IDiscountHelper productService = new DiscountHelper();
        static void Main(string[] args)
        {
            //Load All Products from list.
            try {
                DisplayProducts();

                do
                {
                    //add user product and display
                    AddUserProduct();
                    Console.WriteLine();
                    Console.Write("Press N to Discount Or Other for Add:");
                } while (Console.ReadLine() != "N");

                //calculate discount
                ApplyDiscount();
            }
            catch (Exception ex)
            {
                Console.WriteLine("User Exception Occures or user input wrong, Please Restart the Application");
            }

            finally
            {
                Console.ReadLine();
            }                       
        }

        private static void DisplayProducts()
        {
            foreach (Product p in LoadItems())
            {
                Console.Write("{0}.{1} ", p.ProductId, p.ProductName);
            }
        }

        private static List<Product> LoadItems()
        {            
            List<Product> products = productService.GetAllProducts();
            return products;
        }

        private static void AddUserProduct()
        {
            Console.WriteLine();
            Console.WriteLine();
            Console.Write("Enter Product Id: ");
            string _code = Console.ReadLine();

            Console.WriteLine();
            Console.Write("Enter Product Quantity: ");
            string _qty = Console.ReadLine();

            
            _userCarts = productService.AddUserProduct(Convert.ToInt32(_code), Convert.ToInt32(_qty));

            DisplayCart(productService._subTot);
        }

        private static void ApplyDiscount()
        {
            Console.WriteLine();
            Console.Write("1. Discount for all  2. Discount on One Product, 3. Buy 2 Get 1 Free, Your Choice: ");
            string discType = Console.ReadLine();
            if (discType == "1")
            {
                Console.WriteLine();
                Console.WriteLine("Applied 10% Discount on all Products");
                productService.CalculateAllDiscount();
                Console.WriteLine("----------------------------- Grand Total: {0}", productService._grandTot);
            }else if (discType == "2")
            {
                Console.WriteLine();
                Console.Write("Enter Product Id :");
                string _code = Console.ReadLine();
                
                Console.WriteLine();
                Console.WriteLine("Applied 15% Discount on below Product");

                UserCart uCart = productService.CalculateProductDiscount(Convert.ToInt32(_code));
                
                Console.WriteLine();
                Console.WriteLine("----------------------------------------------");
                Console.WriteLine("Code   Item          Price   Qty     Total");
                Console.WriteLine("----------------------------------------------");

                Console.WriteLine("{0}      {1}         {2}    {3}      {4}", uCart._Product.ProductId, uCart._Product.ProductName, uCart._Product.ProductPrice, uCart._Qty, uCart._DisTotal);

                Console.WriteLine("----------------------------- Grand Total: {0}", productService._grandTot);
            } else if (discType == "3")
            {
                Console.WriteLine();
                Console.Write("Enter Product Id :");
                string _code = Console.ReadLine();

                Console.WriteLine();
                Console.WriteLine("Applied Buy 2 Get 1 Free");

                _userCarts = productService.CalculateQtyDiscount(Convert.ToInt32(_code));

                DisplayCart(productService._subTot);
            }
            Console.WriteLine();
        }

        private static void DisplayCart(double subTot) {
            Console.WriteLine();
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine("Code   Item          Price   Qty     Total");
            Console.WriteLine("----------------------------------------------");

            foreach (UserCart i in _userCarts)
            {
                Console.WriteLine("{0}      {1}         {2}    {3}      {4}", i._Product.ProductId, i._Product.ProductName, i._Product.ProductPrice, i._Qty,i._Total);
            }

            Console.WriteLine();
            Console.WriteLine("---------------------------------------------");
            Console.WriteLine("----------------------------- Grand Total: {0}", subTot);
        }
    }
}
