﻿using AbstractDiscLib.Factory.IFactory;
using AbstractDiscLib.Product.IProduct;

namespace AbstractDiscLib
{
    public class DiscountClient
    {
        AbstractPriceDiscountProduct price;
        AbstractQtyDiscountProduct quantity;

        public DiscountClient(AbstractDiscountFactory factory, int disc) {
            price = factory.GetAbstractPriceDiscountProduct(disc);
            quantity = factory.GetAbstractQtyDiscountProduct();
        }

        public double GetPriceDiscount(double amount) {
            return price.GetDiscountPrice(amount);
        }

        public int GetQtyDiscount(int qty) {
            return quantity.GetDiscountQty(qty);
        }
    }
}
