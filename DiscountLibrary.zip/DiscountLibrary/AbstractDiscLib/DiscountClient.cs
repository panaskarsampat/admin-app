﻿using AbstractDiscLib.Factory.IFactory;
using AbstractDiscLib.Product.IProduct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractDiscLib
{
    public class DiscountClient
    {
        AbstractPriceDiscountProduct price;
        AbstractQtyDiscountProduct quantity;

        public DiscountClient(AbstractDiscountFactory factory, int disc) {
            price = factory.GetAbstractPriceDiscountProduct(disc);
            quantity = factory.GetAbstractQtyDiscountProduct();
        }

        public double GetPriceDiscount(double amount) {
            return price.GetDiscountPrice(amount);
        }

        public int GetQtyDiscount(int qty) {
            return quantity.GetDiscountQty(qty);
        }
    }
}
