﻿using AbstractDiscLib.Factory.IFactory;
using AbstractDiscLib.Product;
using AbstractDiscLib.Product.IProduct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractDiscLib.Factory
{
    public class ConcreateDiscountFactory : AbstractDiscountFactory
    {
        public AbstractPriceDiscountProduct GetAbstractPriceDiscountProduct(int Discount)
        {
            switch (Discount) {
                case 10:
                    return new ConcreateDiscount10_Product();
                case 15:
                    return new ConcreateDiscount15_Product();
                case 20:
                    return new ConcreateDiscount20_Product();
                case 30:
                    return new ConcreateDiscount30_Product();
                default:
                    throw new ApplicationException("Discount not valid");                    
            }            
        }

        public AbstractQtyDiscountProduct GetAbstractQtyDiscountProduct()
        {
            return new ConcreateDiscountB2G1_Product();
        }
    }
}
