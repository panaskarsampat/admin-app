﻿using AbstractDiscLib.Product.IProduct;

namespace AbstractDiscLib.Factory.IFactory
{
    public interface AbstractDiscountFactory
    {
        AbstractPriceDiscountProduct GetAbstractPriceDiscountProduct(int Discount);
        AbstractQtyDiscountProduct GetAbstractQtyDiscountProduct();
    }
}
