﻿using AbstractDiscLib.Product.IProduct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractDiscLib.Factory.IFactory
{
    public interface AbstractDiscountFactory
    {
        AbstractPriceDiscountProduct GetAbstractPriceDiscountProduct(int Discount);
        AbstractQtyDiscountProduct GetAbstractQtyDiscountProduct();
    }
}
