﻿using AbstractDiscLib.Product.IProduct;
using System;

namespace AbstractDiscLib.Product
{
    public class ConcreateDiscount10_Product : AbstractPriceDiscountProduct
    {
        public double GetDiscountPrice(double Amount)
        {
            //return 10% discounted Amount            
            return Math.Round((Amount - (Amount * (10.0 / 100))));
        }
    }
}
