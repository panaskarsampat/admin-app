﻿using AbstractDiscLib.Product.IProduct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractDiscLib.Product
{
    public class ConcreateDiscount10_Product : AbstractPriceDiscountProduct
    {
        public double GetDiscountPrice(double Amount)
        {
            //return 10% discounted Amount            
            return Math.Round((Amount - (Amount * (10.0 / 100))));
        }
    }
}
