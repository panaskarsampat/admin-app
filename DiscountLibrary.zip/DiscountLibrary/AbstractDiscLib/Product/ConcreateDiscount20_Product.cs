﻿using AbstractDiscLib.Product.IProduct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractDiscLib.Product
{
    class ConcreateDiscount20_Product : AbstractPriceDiscountProduct
    {
        public double GetDiscountPrice(double Amount)
        {
            //return 20 percent discounted Amount on if previous total Amount
            return Amount -(Amount * (20.0 / 100));
        }
    }
}
