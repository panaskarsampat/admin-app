﻿using AbstractDiscLib.Product.IProduct;

namespace AbstractDiscLib.Product
{
    class ConcreateDiscount15_Product : AbstractPriceDiscountProduct
    {
        public double GetDiscountPrice(double Amount)
        {
            //retun 15 percent discounted Amount on one product
            return Amount - (Amount * (15.0 / 100));
        }
    }
}
