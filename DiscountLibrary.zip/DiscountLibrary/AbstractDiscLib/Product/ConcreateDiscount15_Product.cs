﻿using AbstractDiscLib.Product.IProduct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractDiscLib.Product
{
    class ConcreateDiscount15_Product : AbstractPriceDiscountProduct
    {
        public double GetDiscountPrice(double Amount)
        {
            //retun 15 percent discounted Amount on one product
            return Amount - (Amount * (15.0 / 100));
        }
    }
}
