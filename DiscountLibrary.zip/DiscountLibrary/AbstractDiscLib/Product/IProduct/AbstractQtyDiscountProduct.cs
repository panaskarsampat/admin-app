﻿namespace AbstractDiscLib.Product.IProduct
{
    public interface AbstractQtyDiscountProduct
    {
        int GetDiscountQty(int qty);
    }
}
