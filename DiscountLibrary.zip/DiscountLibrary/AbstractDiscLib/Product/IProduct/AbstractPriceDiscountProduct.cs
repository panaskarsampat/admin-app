﻿namespace AbstractDiscLib.Product.IProduct
{
    public interface AbstractPriceDiscountProduct
    {
        double GetDiscountPrice(double Amount);
    }
}
