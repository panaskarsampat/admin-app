﻿using AbstractDiscLib.Product.IProduct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractDiscLib.Product
{
    class ConcreateDiscountB2G1_Product : AbstractQtyDiscountProduct
    {
        public int GetDiscountQty(int qty)
        {            
            if (qty >= 2)
            {
                var qToAdd = qty / 2;
                qty += qToAdd; 
            }
            return qty ;
        }
    }
}
