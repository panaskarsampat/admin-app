﻿using AbstractDiscLib.Product.IProduct;

namespace AbstractDiscLib.Product
{
    class ConcreateDiscountB2G1_Product : AbstractQtyDiscountProduct
    {
        public int GetDiscountQty(int qty)
        {            
            if (qty >= 2)
            {
                var qToAdd = qty / 2;
                qty += qToAdd; 
            }
            return qty ;
        }
    }
}
