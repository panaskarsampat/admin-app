﻿using AbstractDiscountLib.Classes.ConcreteProduct;
using AbstractDiscountLib.Interface.IFactory;
using AbstractDiscountLib.Interface.IProduct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractDiscountLib.Classes.ConcreteFactory
{
    class ConcretePriceDiscountFactory : AbstractDiscountFactory
    {
        public IPriceDiscountProduct GetPriceDiscountProduct()
        {
            return new ConcretePriceDiscountProduct();
        }

        public IQtyDiscountProduct GetQtyDiscountProduct()
        {
            throw new NotImplementedException();
        }
    }
}
