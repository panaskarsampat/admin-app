﻿using AbstractDiscountLib.Interface.IFactory;
using AbstractDiscountLib.Interface.IProduct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractDiscountLib.Classes.ConcreteFactory
{
    class ConcreteQtyDiscountFactory : AbstractDiscountFactory
    {

        IPriceDiscountProduct AbstractDiscountFactory.GetPriceDiscountProduct()
        {
            throw new NotImplementedException();
        }

        IQtyDiscountProduct AbstractDiscountFactory.GetQtyDiscountProduct()
        {
            throw new NotImplementedException();
        }
    }
}
