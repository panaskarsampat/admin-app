﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiscountEntitiesLib
{
    public class UserCart
    {
        public Product _Product { get; set; }
        public int _Qty { get; set; }
        public double _Total { get; set; }        
        public double _DisTotal { get; set; }
    }
}
