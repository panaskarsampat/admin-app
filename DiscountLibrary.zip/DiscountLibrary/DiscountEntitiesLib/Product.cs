﻿namespace DiscountEntitiesLib
{
    public class Product
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public double ProductPrice { get; set; }
        public bool IsDiscount { get; set; }
    }
}
