﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using DiscountBusinessLib;
using DiscountEntitiesLib;

namespace DiscountUnitTest
{
    [TestClass]
    public class UnitTest1
    {        
        [TestMethod]
        public void ProductList()
        {
            //Act
            List<Product> products = ProductLists.GetProducts();

            //Assert
            Assert.IsTrue(products.Count > 0, "GetAllProducts returned no Products");
        }

        [TestMethod]
        public void AddUserCart()
        {
            //Arrange
            DiscountHelper discountHelper = new DiscountHelper();
            int productId = 1;
            int productQty = 5;

            //Act
            List<UserCart> userCarts = discountHelper.AddUserProduct(productId, productQty);

            //Assert
            Assert.AreNotEqual(productId, userCarts.Count > 0, "Creating new record does not return id");
        }

        [TestMethod]
        public void DiscountAll()
        {
            //Arrange
            DiscountHelper discountHelper = new DiscountHelper();

            //Act 
            double grndTotal = discountHelper._grandTot;

            //Assert
            Assert.IsNotNull(grndTotal);
        }

        [TestMethod]
        public void DiscountForProduct()
        {
            //Arrange
            DiscountHelper discountHelper = new DiscountHelper();
            int productId = 1;

            //Act 
                      
            double grndTotal = discountHelper._grandTot;

            //Assert
            Assert.IsNotNull(grndTotal);            
        }

        [TestMethod]
        public void DiscountOnQty()
        {
            //Arrange
            DiscountHelper discountHelper = new DiscountHelper();
            int productId = 1;

            //Act 
            List<UserCart> userCarts = discountHelper.CalculateQtyDiscount(productId);
            
            //Assert            
            Assert.AreNotEqual(productId, userCarts.Count>0, "User Cart null");
            
        }
    }
}
